package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ValueAnimator
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var orb: TextView
    private lateinit var tts: TextToSpeech
    private var pendingNumber: String? = null
    private var pendingContactName: String? = null
    private var waitingForCallConfirmation = false
    private val requestAudio = 41
    private val requestSpeech = 42
    private val requestContacts = 43
    private val requestCall = 44

    private val cyan = Color.rgb(55, 205, 255)
    private val navy = Color.rgb(3, 10, 27)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        window.statusBarColor = navy
        window.navigationBarColor = Color.BLACK

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 28, 26, 24)
            setBackgroundColor(navy)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            letterSpacing = 0.20f
            gravity = Gravity.CENTER
            setTextColor(cyan)
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT  //  V2"
            textSize = 10f
            letterSpacing = 0.15f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }
        orb = TextView(this).apply {
            text = "B"
            textSize = 86f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 58, 105), Color.rgb(2, 13, 35), Color.rgb(0, 93, 145))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(3, cyan)
            }
            elevation = 18f
            setPadding(0, 0, 0, 0)
        }
        status = TextView(this).apply {
            text = "SYSTEM ONLINE  •  TAP TO SPEAK"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 20)
        }
        val listen = Button(this).apply {
            text = "🎙  ACTIVATE JARVIS"
            setOnClickListener { startListening() }
        }
        val help = TextView(this).apply {
            text = "\nTRY SAYING\n“Open YouTube”  •  “Call Mom”\n“Search for MHT CET”  •  “Battery status”\n\nFor calls, JARVIS asks for Yes/No before dialing."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(8, 20, 8, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(Space(this), LinearLayout.LayoutParams(1, 22))
        layout.addView(orb, LinearLayout.LayoutParams(210, 210).apply { gravity = Gravity.CENTER })
        layout.addView(status)
        layout.addView(listen, LinearLayout.LayoutParams(-1, -2))
        layout.addView(help)
        setContentView(layout)
        startOrbAnimation()
    }

    private fun startOrbAnimation() {
        ValueAnimator.ofFloat(0.94f, 1.06f).apply {
            duration = 1450
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val scale = it.animatedValue as Float
                orb.scaleX = scale
                orb.scaleY = scale
                orb.alpha = 0.88f + (scale - 0.94f) * 0.7f
            }
            start()
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    private fun speak(message: String) {
        status.text = message.uppercase(Locale.getDefault())
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (waitingForCallConfirmation) "Say yes or no" else "Speak a command for JARVIS")
        }
        try {
            startActivityForResult(intent, requestSpeech)
        } catch (_: Exception) {
            speak("Speech recognition is not available on this device.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        when (requestCode) {
            requestAudio -> if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
                else speak("Microphone permission is needed for voice commands.")
            requestContacts -> if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                val name = pendingContactName
                if (name != null) findContact(name)
            } else {
                pendingContactName = null
                speak("Contacts permission was not granted.")
            }
            requestCall -> if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) placeCall()
                else speak("Phone permission was not granted. I will not place the call.")
        }
    }

    @Deprecated("Uses Android's speech recognition activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestSpeech || resultCode != RESULT_OK) return
        val heard = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if (heard.isNotBlank()) {
            if (waitingForCallConfirmation) handleCallConfirmation(heard) else handleCommand(heard)
        }
    }

    private fun handleCallConfirmation(raw: String) {
        val answer = raw.lowercase(Locale.getDefault()).trim()
        when {
            answer == "yes" || answer.contains("yes") || answer.contains("confirm") -> {
                waitingForCallConfirmation = false
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), requestCall)
                } else placeCall()
            }
            answer == "no" || answer.contains("no") || answer.contains("cancel") -> {
                waitingForCallConfirmation = false
                pendingNumber = null
                pendingContactName = null
                speak("Call cancelled.")
            }
            else -> {
                speak("Please say yes to call, or no to cancel.")
                startListening()
            }
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        val lower = command.lowercase(Locale.getDefault())
        when {
            lower.startsWith("call ") -> {
                val target = command.substringAfter(" ", "").trim()
                val number = target.filter { it.isDigit() || it == '+' }
                if (number.length >= 5) {
                    pendingNumber = number
                    pendingContactName = target
                    askCallConfirmation(target, number)
                } else {
                    pendingContactName = target
                    if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), requestContacts)
                    } else findContact(target)
                }
            }
            lower == "yes" && pendingNumber != null -> handleCallConfirmation("yes")
            lower == "no" && pendingNumber != null -> handleCallConfirmation("no")
            lower.startsWith("search ") || lower.startsWith("google ") -> {
                val query = command.substringAfter(" ").trim()
                speak("Searching the web.")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
            }
            lower.startsWith("open ") -> openApp(command.substringAfter(" ").trim())
            lower.contains("time") -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                speak("The time is $now.")
            }
            lower.contains("battery") -> {
                val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra("level", -1) ?: -1
                speak(if (level >= 0) "Battery level is $level percent." else "Battery information is unavailable.")
            }
            else -> speak("I heard $command. That command is not supported yet.")
        }
    }

    private fun findContact(query: String) {
        val matches = mutableListOf<Pair<String, String>>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$query%")
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, projection, selection, args, null)
            cursor?.use {
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext()) {
                    val name = it.getString(nameIndex) ?: continue
                    val number = it.getString(numberIndex) ?: continue
                    if (matches.none { pair -> pair.second == number }) matches.add(name to number)
                }
            }
        } catch (_: Exception) {
            speak("I could not read your contacts.")
            return
        }
        when {
            matches.isEmpty() -> {
                pendingContactName = null
                speak("I could not find $query in your contacts.")
            }
            matches.size > 1 -> {
                pendingContactName = null
                speak("I found more than one match for $query. Please say the full contact name.")
            }
            else -> {
                val (name, number) = matches.first()
                pendingContactName = name
                pendingNumber = number.filter { it.isDigit() || it == '+' }
                askCallConfirmation(name, pendingNumber!!)
            }
        }
    }

    private fun askCallConfirmation(name: String, number: String) {
        pendingContactName = name
        pendingNumber = number
        waitingForCallConfirmation = true
        speak("I found $name. Should I call?")
        // Start a second speech session after the spoken question finishes.
        orb.postDelayed({ if (waitingForCallConfirmation) startListening() }, 1800)
    }

    private fun placeCall() {
        val number = pendingNumber
        if (number.isNullOrBlank()) {
            speak("I do not have a valid number to call.")
            return
        }
        try {
            speak("Calling ${pendingContactName ?: "the number"}.")
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
        } catch (_: SecurityException) {
            speak("I cannot place the call without phone permission.")
        } catch (_: Exception) {
            speak("The call could not be started.")
        } finally {
            waitingForCallConfirmation = false
        }
    }

    private fun openApp(name: String) {
        val candidates = listOf(
            "youtube" to "com.google.android.youtube",
            "instagram" to "com.instagram.android",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "settings" to "com.android.settings",
            "maps" to "com.google.android.apps.maps"
        )
        val pkg = candidates.firstOrNull { name.lowercase(Locale.getDefault()).contains(it.first) }?.second
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (launch != null) {
            speak("Opening $name.")
            startActivity(launch)
        } else speak("I could not find that app. Try YouTube, Instagram, WhatsApp, Chrome, Maps or Settings.")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
