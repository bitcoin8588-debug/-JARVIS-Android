package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val requestAudio = 41
    private val requestSpeech = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        window.statusBarColor = android.graphics.Color.rgb(2, 10, 25)
        window.navigationBarColor = android.graphics.Color.BLACK
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 36, 28, 28); setBackgroundColor(android.graphics.Color.rgb(2, 10, 25)) }
        val title = TextView(this).apply { text = "J.A.R.V.I.S."; textSize = 32f; letterSpacing = 0.18f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.rgb(75, 205, 255)) }
        val subtitle = TextView(this).apply { text = "PERSONAL ANDROID ASSISTANT"; textSize = 11f; letterSpacing = 0.16f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.LTGRAY) }
        val orb = TextView(this).apply { text = "◉"; textSize = 104f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.rgb(65, 190, 255)); setPadding(0, 34, 0, 28) }
        status = TextView(this).apply { text = "SYSTEM ONLINE  •  TAP TO SPEAK"; textSize = 13f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE); setPadding(0, 8, 0, 28) }
        val listen = Button(this).apply { text = "ACTIVATE JARVIS"; setOnClickListener { startListening() } }
        val help = TextView(this).apply { text = "\nTry: “Open YouTube”, “Search for cats”, “Call 9876543210”, “Text 9876543210 hello”, “What time is it?”\n\nWake-word listening is not enabled in this starter build."; textSize = 13f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.LTGRAY) }
        listOf(title, subtitle, orb, status, listen, help).forEach { layout.addView(it) }
        setContentView(layout)
    }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }
    private fun speak(message: String) { status.text = message.uppercase(Locale.getDefault()); if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a command for JARVIS") }
        try { startActivityForResult(intent, requestSpeech) } catch (_: Exception) { speak("Speech recognition is not available on this device.") }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == requestAudio && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startListening() else speak("Microphone permission is needed for voice commands.")
    }
    @Deprecated("Uses the platform speech recognition activity for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestSpeech || resultCode != RESULT_OK) return
        val command = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if (command.isNotBlank()) handleCommand(command)
    }
    private fun handleCommand(raw: String) {
        val command = raw.trim(); val lower = command.lowercase(Locale.getDefault())
        when {
            lower.startsWith("call ") -> { val number = command.substringAfter(" ", "").filter { it.isDigit() || it == '+' }; if (number.isNotBlank()) { speak("Opening the dialer."); startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))) } else speak("Please say a phone number after call.") }
            lower.startsWith("text ") || lower.startsWith("message ") -> { val parts = command.substringAfter(" ", "").split(" ", limit = 2); if (parts.size == 2 && parts[0].any { it.isDigit() }) { speak("Opening your messaging app. Please review and send."); val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${parts[0]}")); intent.putExtra("sms_body", parts[1]); startActivity(intent) } else speak("Say text, followed by a phone number and your message.") }
            lower.startsWith("search ") || lower.startsWith("google ") -> { val query = command.substringAfter(" ").trim(); speak("Searching the web."); startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))) }
            lower.startsWith("open ") -> openApp(command.substringAfter(" ").trim())
            lower.contains("time") -> { val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()); speak("The time is $now.") }
            lower.contains("battery") -> { val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)); val level = battery?.getIntExtra("level", -1) ?: -1; speak(if (level >= 0) "Battery level is $level percent." else "Battery information is unavailable.") }
            else -> speak("I heard: $command. That command is not supported yet.")
        }
    }
    private fun openApp(name: String) {
        val candidates = listOf("youtube" to "com.google.android.youtube", "instagram" to "com.instagram.android", "whatsapp" to "com.whatsapp", "chrome" to "com.android.chrome", "settings" to "com.android.settings", "maps" to "com.google.android.apps.maps")
        val pkg = candidates.firstOrNull { name.lowercase().contains(it.first) }?.second
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (launch != null) { speak("Opening $name."); startActivity(launch) } else speak("I could not find that app. Try YouTube, Instagram, WhatsApp, Chrome, Maps or Settings.")
    }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
