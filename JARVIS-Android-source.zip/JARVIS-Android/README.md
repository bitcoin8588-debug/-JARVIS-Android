# J.A.R.V.I.S. Android

A lightweight native Kotlin Android starter app with a dark blue Iron-Man-inspired interface.

## Included commands
- Tap-to-speak voice recognition using Android's speech recognition UI
- `Call 9876543210` opens the dialer; it does not place a call automatically
- `Text 9876543210 hello there` opens the SMS composer for review and sending
- `Open YouTube`, `Open Instagram`, `Open WhatsApp`, `Open Chrome`, `Open Maps`, `Open Settings`
- `Search for ...` or `Google ...`
- `What time is it?`
- `Battery status`

## Build APK using only your phone
1. Create a new GitHub repository named `JARVIS-Android`.
2. Upload the contents of this project to the repository root, including the hidden `.github` folder.
3. Open the repository's **Actions** tab.
4. Select **Build JARVIS APK** and tap **Run workflow** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
6. Extract the ZIP and install `app-debug.apk`.

## Wake-word limitation
This starter build does **not** continuously listen for “Jarvis”; it listens after tapping the button. Reliable always-on wake-word detection requires a dedicated wake-word engine and suitable foreground/assistant integration. Android restricts background microphone use, so this must be implemented and tested as a separate phase with visible microphone use and battery controls.

## Privacy and safety
- Calls open the dialer for confirmation; no call is placed automatically.
- SMS opens the messaging app for review; no message is sent automatically.
- Speech recognition may use the device's configured recognition service. Check that provider's privacy settings.
- No API key is required for this starter app.

## Technical notes
- Native Kotlin Android app
- Minimum Android version: Android 8.0 (API 26)
- Debug APK is for testing; sign a release APK before public distribution.
